import { api } from "./api";

export const staffService = {
  getUsers: async () => {
    const response = await api.get("/users/");
    return response.data;
  },

  createUser: async (data) => {
    const response = await api.post("/users/", data);
    return response.data;
  },

  getUser: async (id) => {
    const response = await api.get(`/users/${id}`);
    return response.data;
  },

  updateUser: async (id, data) => {
    const response = await api.put(`/users/${id}`, data);
    return response.data;
  },

  deactivateUser: async (id) => {
    const response = await api.delete(`/users/${id}`);
    return response.data;
  },
};